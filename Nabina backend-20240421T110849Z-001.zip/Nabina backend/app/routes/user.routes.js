const { authJwt } = require("../middlewares");
const { verifySignUp } = require("../middlewares");
const controller = require("../controllers/user.controller");
/**upoad image */

multer = require("multer");
uuidv4 = require("uuid/v4");
const DIR = "/Users/thahsinashaik/Desktop/image";

const path = require("path");
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const originalname = `${uuidv4()}${ext}`;
    cb(null, originalname);
  },
});
var upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
});
const cpUpload = upload.array("profileImg", 6);
/** */
module.exports = function (app) {
  app.use(function (req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  app.get("/api/go/get_user", [authJwt.verifyToken], controller.getUser);
  app.get(
    "/api/go/get_all_user",
    [authJwt.verifyToken],
    controller.getAllUsers
  );
  app.post("/api/go/get_user_locally", controller.getUser1);
  app.post(
    "/api/go/get_family_members",
    [authJwt.verifyToken],
    controller.getFamilyMember
  );
  app.post(
    "/api/go/update_user",
    cpUpload,
    [authJwt.verifyToken],
    controller.userUpdate
  );
  app.delete(
    "/api/go/delete_all_user",
    [authJwt.verifyToken],
    controller.deleteAllUsers
  );
  app.delete(
    "/api/go/delete_user",
    [authJwt.verifyToken],
    controller.deleteUser
  );
  app.post(
    "/api/go/add_user",
    cpUpload,
    [
     verifySignUp.checkDuplicateUsernameOrEmail,
     authJwt.verifyToken
    ],
    controller.addUser
  );
  app.post("/api/go/check_duplicate_logininfo", controller.checkDuplicate);
};
