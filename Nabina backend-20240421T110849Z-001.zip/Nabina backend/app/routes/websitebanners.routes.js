const { authJwt } = require("../middlewares");
//const { verifySignUp } = require("../middlewares");
const controller = require("../controllers/websitebanners.controller");
/**upoad banner */

multer = require('multer')
uuidv4 = require('uuid/v4')
const DIR = './public/banners';

const path = require("path")
const storage = multer.diskStorage({
   destination: (req, file, cb) => {
       cb(null, DIR);
   },
   filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const originalname = `${uuidv4()}${ext}`;
      cb(null, originalname);
   }
});
var upload = multer({
   storage: storage,
   fileFilter: (req, file, cb) => {
       if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
           cb(null, true);
       } else {
           cb(null, false);
           return cb(new Error('Only png jpg jpeg format allowed!'));
       }
   }
});
const cpUpload =upload.array('websitebannerFile', 6)
  /** */
module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  app.get("/api/go/get_website_banners", [authJwt.verifyToken],controller.getBanners);
  app.post("/api/go/add_website_banners", cpUpload,[authJwt.verifyToken],controller.bannersCreate);
  app.patch("/api/go/update_website_banners", cpUpload,[authJwt.verifyToken],controller.bannersUpdate);
  app.delete("/api/go/delete_website_banners", cpUpload,[authJwt.verifyToken],controller.deleteBanner);
 
};
