module.exports = {
  secret: "goK!pusp6ThEdURDPRakdvkUtRenOwUhAsWUCLssdgsheBazl!uJLPlS8EbreWLdrupIwabRAsiBu"
};
