const nodemailer = require('nodemailer');
const ejs = require('ejs');
const transport = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: '587',
  auth: {
    user: 'bensaidyazid@gmail.com',
    pass: 'ivykaayhfkdwdxjp'
  }
});

const sendEmail = (receiver, subject, content) => {
  ejs.renderFile(__dirname + '/app/emailTemplates/welcome.ejs', { receiver, content }, (err, data) => {
    if (err) {
      console.log(err);
    } else {
      var mailOptions = {
        from: 'bensaidyazid@gmail.com',
        to: receiver,
        subject: subject,
        html: data
      };

      transport.sendMail(mailOptions, (error, info) => {
        if (error) {
          return console.log(error);
        }
        console.log('Message sent: %s', info.messageId);
      });
    }
  });
};

module.exports = {
  sendEmail
};
