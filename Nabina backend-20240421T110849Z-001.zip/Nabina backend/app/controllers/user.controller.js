const db = require("../models");
const User = db.user;
var bcrypt = require("bcryptjs");
var bcrypt1 = require("bcrypt");
const fetch = (...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args));

exports.getUser = async (req, res) => {
  try {
    const id = req.body.userId;
    const user = await User.findById(id, {
      password: 0,
      archive: 0,
      merhOrgId: 0,
      registrationCode: 0,
      dovice: 0,
      privilege: 0,
    });
    //console.log('man3raf')
    if (!user.passcard) {
      try {
        const bdy = {
          pass: {
            secondary_fields: [
              {
                key: "a648d7",
                label: "" + user.username,
              },
              {
                key: "13dd0c",
                label: "" + user.userToDate,
              },
            ],
          },
        };
        credentials = btoa("golalita:B_I9XNXsPGhYf5wNOPlL7w");
        const url =
          "https://api.passworks.io/v2/coupons/66ebb4f0-96b8-4fa1-b83a-eeffc02f8edf/passes";
        const response = await fetch(url, {
          method: "POST",
          headers: {
            Authorization: `Basic ${credentials}`,
            "Content-Type": "application/json",
          },
          // body:JSON.stringify(bdy)
          body: JSON.stringify(bdy),
        });
        const data = await response.json();
        user.passcard = data.page_url;
        console.log(data.page_url);
      } catch (err) {
        console.log("error :" + err);
      }
    }
    const user1 = await user.save();
    res.json(user);
  } catch (err) {
    res.send("Error" + err);
  }
};
exports.addUser = async (req, res) => {
  // Our register logic starts here
  try {
    let profileImg = [];
    const url =
      req.protocol +
      "://" +
      req.get("host") +
      "/Users/thahsinashaik/Desktop/image/";
    if (req.files) {
      //console.log(req.files[0].length);
      //if (req.files[0]) {profileImg = url + req.files[0].filename;}
      if (req.files[0]) {
        profileImg.push(req.files[0].filename);
      }
    }

    const {
      password,
      //phone,
      email,
      firstName,
      lastName,
      role,
      position,
    } = req.body;
    console.log(req.body.email);
    // Validate user input
    if (
      !(
        firstName &&
        lastName &&
        role &&
        position &&
        email &&
        //phone &&
        password
      )
    ) {
      res.status(400).send("All input is required");
    } else {
      //Encrypt user password
      encryptedPassword = await bcrypt1.hash(password, 10);
      // Create user in our database
      const user = new User({
        //phone,
        email: email.toLowerCase(), // sanitize: convert email to lowercase
        password,
        role,
        position,
        firstName,
        lastName,
        profileImg: profileImg,
      });

      // return new user
      const user1 = await user.save();
      res.status(200).json(user1); //
    }
  } catch (err) {
    console.log(err);
    res.status(402).send({ message: err });
  }

  // Our register logic ends here
};

exports.userUpdate = async (req, res) => {
  try {
    if (!req.body.userId) {
      return res.status(400).send({
        message: "userId is required to allow the update !!! ",
      });
    } else {
      try {
        const user = await User.findById(req.body.userId);
        if (!user) res.status(400).send("No User found with this ID");
        else {
          if (user.email != req.body.email) {
            const user2 = await User.find({ email: req.body.email });
            if (user2.length>1) {
              res.status(400).send("Failed! email is already in use!");
            } 
            else {
              const profileImg =[];
              //if (req.body.deleteProfileImg) profileImg = [];
              const url =
                req.protocol +
                "://" +
                req.get("host") +
                "/Users/thahsinashaik/Desktop/image/";

              if (req.files) {
                profileImg = []
                if (req.files[0]) {
                  profileImg.push(url+req.files[0].filename);
                }
              }
              (user.firstName = req.body.firstName),
                (user.lastName = req.body.lastName),
                (user.position = req.body.position),
                (user.profileImg = profileImg),
                (user.role = req.body.role),
                (user.password = req.body.password);
              user.email = req.body.email;
            }
          } 
          else {
            const profileImg = user.profileImg;
            if (req.body.deleteProfileImg) profileImg = [];
            const url =
              req.protocol +
              "://" +
              req.get("host") +
              "/Users/thahsinashaik/Desktop/image/";

            if (req.files) {
              if (req.files[0]) {
                profileImg.push(url+req.files[0].filename);
              }
            }

            (user.firstName = req.body.firstName),
              (user.lastName = req.body.lastName),
              (user.position = req.body.position),
              (user.profileImg = profileImg),
              (user.role = req.body.role),
              (user.password = req.body.password);
          }

          const user1 = await user.save();
          res.status(200).json(user1); //
        }
      } catch (err) {
        console.log(2);
        res.status(402).send({ message: err });
      }
    }
  } catch (err) {
    res.status(402).send({ message: err });
  }
};

exports.getUser1 = async (req, res) => {
  try {
    const id = req.body.userId;
    console.log(id);
    const user = await User.findById(id, {
      password: 0,
      archive: 0,
      merhOrgId: 0,
      registrationCode: 0,
      dovice: 0,
      privilege: 0,
    });
    const user1 = await user.save();
    res.json(user1);
  } catch (err) {
    res.send("Error" + err);
  }
};
exports.getFamilyMember = async (req, res) => {
  try {
    if (!req.body.userId) {
      res.send("Please user Id  is missed");
    } else {
      console.log(req.body.userId);
      const user = await User.find(
        { parentUser: req.body.userId },
        {
          password: 0,
          archive: 0,
          merhOrgId: 0,
          registrationCode: 0,
          dovice: 0,
          privilege: 0,
        }
      );
      //const user1= await user.save()
      res.json(user);
    }
  } catch (err) {
    res.send("Error" + err);
  }
};
exports.deleteAllUsers = async (req, res) => {
  try {
    const user = await User.deleteMany({});

    res.send("succsufl");
  } catch (err) {
    res.send("Error" + err);
  }
};
exports.checkDuplicate = (req, res) => {
  // phone
  if (req.body.phone) {
    User.findOne({
      phone: req.body.phone,
    }).exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
      }
      if (user) {
        res.json({
          success: true,
          error: "this phone is already in use!",
        });
      } else {
        res.json({
          success: false,
          error: "No user registred with this Number Phone!",
        });
      }
    });
  } else if (req.body.email) {
    User.findOne({
      email: req.body.email,
    }).exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
      }
      if (user) {
        res.json({
          success: true,
          error: "this email is already in use!",
        });
      } else
        res.json({
          success: false,
          error: "No user registred with this Number email!",
        });
    });
  } else
    res.json({
      success: false,
      error: "email or phone is required to check!",
    });
};
exports.getAllUsers = async (req, res) => {
  try {
    const user = await User.find({}, {});

    res.json({
      success: true,
      resultat: user,
    });
  } catch (err) {
    res.json({
      success: false,
      error: err,
    });
  }
};

exports.deleteUser = async (req, res) => {
  if (!req.body.userId) {
    res.status(400).send("User Id is required");
  } else {
    try {
      const user = await User.findOneAndDelete({ _id: req.body.userId });
      if (!user) res.status(400).send("No User found with this ID");
      else {
        res.send("User  deleted !!!");
      }
    } catch (err) {
      res.send("Error" + err);
    }
  }
};
