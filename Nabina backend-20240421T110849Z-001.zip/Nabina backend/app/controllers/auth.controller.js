const config = require("../config/auth.config");
const db = require("../models");
const User = db.user;
var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");
var bcrypt1 = require("bcrypt");
var UUID = require("uuid-int");
var moment = require("moment");

const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;

exports.signup = async (req, res) => {
  // Our register logic starts here

  if (req.authType) {
    if (req.authType === "email&password") {
      try {
        // Get user input
        const {
          password,
          username,
          merhOrgId,
          registrationCode,
          phone,
          email,
          privilege,
          userType,
          identifier,
          parentUser,
        } = req.body;
        // date = new Date(req.body.userToDate)
        var date = moment.utc(req.body.userToDate);
        // Validate user input
        if (
          !(
            username &&
            email &&
            merhOrgId &&
            registrationCode &&
            phone &&
            password
          )
        ) {
          res.status(400).send("All input is required");
        }
        //Encrypt user password
        encryptedPassword = await bcrypt1.hash(password, 10);
        const id = 0;
        const generator = UUID(id);
        // Create user in our database
        const user = new User({
          username,
          merhOrgId,
          registrationCode,
          phone,
          email: email.toLowerCase(), // sanitize: convert email to lowercase
          password: encryptedPassword,
          codebare: generator.uuid(),
          userToDate: date,
          privilege,
          userType,
          identifier,
          parentUser,
        });

        // return new user
        const user1 = await user.save();
        res.status(200).json(user1); //
      } catch (err) {
        console.log(err);
      }
    } else if (req.authType === "Google") {
      app.use(passport.initialize());
      passport.serializeUser((user, done) => {
        done(null, user);
      });
      passport.deserializeUser((user, done) => {
        done(null, user);
      });
    }
  } else {
    res.status(400).send("Authentication type is required");
  }

  // Our register logic ends here
};
exports.signin = (req, res) => {
  try {
    const { login, password } = req.body;
    if (!(login && password)) {
      res.status(400).send("Email & Password are required");
    } else {
      User.findOne({
        email: login,
      }).exec((err, user) => {
        if (err) {
          res.status(402).send({ message: err });
          return;
        }
        if (!user) {
          return res.status(400).send({ message: "User Not found." });
        } else {
          if (req.body.password != user.password) {
            return res.status(400).send({
              accessToken: null,
              message: "Invalid Password!",
            });
          } else {
          }
        }

        const token = jwt.sign(
          {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email,
            role: user.role,
            position: user.position,
          },
          config.secret,
          {
            algorithm: "HS256",
            allowInsecureKeySizes: true,
            expiresIn: 86400, // 24 hours
          }
        );
        res.status(200).send({
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          position: user.position,
          accessToken: token,
        });
      });
    }
  } catch (err) {
    console.log(err);
  }
};
