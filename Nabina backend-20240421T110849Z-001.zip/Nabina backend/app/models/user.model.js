const mongoose = require("mongoose");

const User = mongoose.model(
  "User",
  new mongoose.Schema({
    email: {
      type: String,
      required: false,
    },
    password: {
      type: String,
      required: false,
    },
    firstName: {
      type: String,
      required: false,
    },
    lastName: {
      type: String,
      required: false,
    },
    phone: {
      type: String,
      required: false,
    },
    role: {
      type: String,
      required: false,
    },
    profileImg: {
      type: Array,
      required: false,
    },
    position: {
      type: String,
      required: false,
    },
  })
);

module.exports = User;
